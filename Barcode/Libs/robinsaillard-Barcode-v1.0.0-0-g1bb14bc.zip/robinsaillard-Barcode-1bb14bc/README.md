# Barcode

Cette application permet l'ouverture de lien scanné depuis une zapette (Inateck BCST-52) 


