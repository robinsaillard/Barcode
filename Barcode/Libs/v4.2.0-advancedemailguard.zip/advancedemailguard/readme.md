# Advanced Anti Spam Google reCAPTCHA

Protects your shop against spam and abuse with Google reCAPTCHA and other validation methods.